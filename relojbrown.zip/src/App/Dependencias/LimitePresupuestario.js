import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import MUICont from 'material-ui/styles/MuiThemeProvider';
import {TextField,Paper,RaisedButton} from 'material-ui';
import dbHandler from '../DBHandler.js';



export default function main(props){
    let root = document.getElementById('main');
    root.limpiar();

    document.getElementById('titulo').innerText = 'Limite Presupuestario';

    ReactDOM.render(
        <div style={{margin:"30px"}}>
            <MUICont>
                <Contenedor/>
            </MUICont>
        </div>,
        root
    )
}



class Contenedor extends Component{


    constructor(props){
        super(props);
        this.state={
            dependencias:[],
            filtro:'',
        }
        this.pedirDependencias = this.pedirDependencias.bind(this);
        this.cargarDependencias = this.cargarDependencias.bind(this);
        this.actualizarDependencias = this.actualizarDependencias.bind(this);
    }

    actualizar(valor,campo){
        this.setState({[campo]:valor});
    }

    actualizarDependencia(){
        
    }

    cargarDependencias(datos){

        let lista = datos;
        lista = lista.map((elem)=>(elem.push(0)));
        this.setState({dependencias:lista});
    }

    pedirDependencias(){

    }


    render(){


        return(
            <Paper>
                <BarraFiltrado funAct={this.actualizar}/>
                <Listado dependencias={this.dependencias} funAct={this.actualizar}/>
            </Paper>
        )

    }


}


class Listado extends Component {
  constructor(props) {
    super(props);
    this.state={
      lista:[],
      filtrado:'',
    }
    this.cargarListado = this.cargarListado.bind(this);
    this.actualizarPadre = props.funAct;
  }


  componentWillReceiveProps(props){

    this.setState({lista:props.lista,filtrado:props.filtrado});
  }

  actualizarDependencia(monto,codigo){

  }


  cargarListado(){

    let final = []; //listado final a mostrar
    let listado = this.state.lista;
    for(let x = 0; x < listado.length; x++){
        if(listado[x][1].includes(this.state.filtrado)){
            final.push(<Linea nombre={listado[x][1]} codigo={listado[x][0]} monto={lista[x][2]} nuevoLimite={lista[x][3]} 
            funAct={this.actualizarDependencia}/>)
        }
    }
    return listado;
  }

  render(){

    return(
      <div>
          {this.cargarListado()}
      </div>
    )
  }


}


class Linea extends Component{
    constructor(props){
        super(props);
        this.state={
            nombre:props.nombre,
            codigo:props.codigo,
            monto:props.limite,
            nuevo:props.nuevoLimite,
            actualizando:false,
        }
        this.actualizarMonto = this.actualizarMonto.bind(this);
    }
    
    actualizarMonto(evento){
        this.setState({nuevo:evento.target.value});
    }

    actualizarDependencia(){

    }
    
    actualizarLimite(){
        let db = new dbHandler();
        
        let datos = this.state;
        datos['repeticion'] = 0;
        this.setState({actualizando:true});
        db.actualizarLimite(null,datos);
        
    }

    render(){

        let boton = <RaisedButton label='Actualizar' onClick={this.actualizarLimite}/>
        if(this.state.actualizando){
            boton = <RaisedButton label='Actualizando' onClick={this.actualizarLimite} disabled/>
        }

        return(
            <div>
                <label style={{width:'150px',display:'inline-block'}} >{this.nombre}</label>
                <label style={{width:'180px',display:'inline-block'}} >Presupuesto Actual: ${this.monto}  </label>
                <TextField value={this.monto} onChange={this.actualizarMonto} />
            </div>
        )
    }
}

class BarraFiltrado extends Component{

    constructor(props){
        super(props);
        this.actualizarPadre = props.funAct;
    }

    render(){


        return(
            <div>
                <TextField onChange={(evento)=>{this.actualizarPadre(evento.target.value,'filtro')}}
                    floatingLabelText={<label>Filtrar por Nombre</label>}/>
            </div>
        )
    }



}
