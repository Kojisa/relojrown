export default class DBHandler{
    
    PORT = ":5000";// ":1382";
    HOST = '0.0.0.0'//"shiki.pythonanywhere.com"; //"127.0.0.1";



    actualizarLimite(fun,datos){

        let fecha = new Date();
        let anio = fecha.getFullYear();
        let mes = fecha.getMonth()+ 1;
        mes = mes + (1 * datos.repeticion);
        if(mes > 12){
            mes = 1;
            anio += 1;
        }
        let armarDatos = {
            'dependence_id':datos.codigo,
            'amount':datos.nuevo,
            'year': anio,
            'month':mes,
        }
        if(datos.repeticion == 12){
            this.enviarPeticion(fun,'/budget','POST',armarDatos,true);
        }
        
        else{
            datos['repeticion'] += 1;
            this.enviarPeticion(()=>{this.actualizarLimite(fun,datos)},'/budget','POST',armarDatos,true);
        }
    }


    crear_articulo(fun,datos){
        this.enviarPeticion(fun,'api/0.1/articles','POST',datos);
    }

    pedir_usuario(fun,us,pas){
        this.enviarPeticion(fun,'api/0.1/login','POST',{'username':us,'password':pas},true)
    }

    enviarPeticion(fun,url,metodo,datos,asinc=true){
        var request = new XMLHttpRequest();
        request.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){

                if (fun != null){
                    if (this.responseText.length > 0){
                        fun(JSON.parse(this.responseText));
                    }

                    else{
                        fun();
                    }
                }
            }
        };
        request.open(metodo,"http://"+this.HOST+this.PORT+"/"+url,asinc);
        var datosFinales = {};

        if (metodo == "POST"){
            request.setRequestHeader('Content-type','application/json');
            request.send(JSON.stringify(datos));
        }

        else {request.send();}
    }
}